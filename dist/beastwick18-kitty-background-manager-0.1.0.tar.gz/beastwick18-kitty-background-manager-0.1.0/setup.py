# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['beastwick18_kitty_background_manager']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=9.1.1,<10.0.0', 'typer[all]>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['kittybg = beastwick18_kitty_background_manager.main:app']}

setup_kwargs = {
    'name': 'beastwick18-kitty-background-manager',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Kitty Background Manager\nA cli program for managing your backgrounds for kitty terminal\n\nThis project is WIP for now.\nI plan to add the following features:\n- [X] Config file\n- [X] Option to dim image\n- [ ] Option to scale and crop image\n\n## Installation\nTo install Kitty Background Manager, you will have to clone the repository and run\n\n```\nchmod +x ./install.sh\n```\n\nfrom within the repository. After that, you can run the install script. \n\nThe program requires poetry, python, and pip to install correctly. \n\n## Running the program\nOnce the program is installed, you can run it by calling the `kittybg` command from your terminal\n\nThe current arguments the program accepts are:\n- `random`: change to a random background\n    - Can be run with `--silent` to hide the output. Useful for randomizing the background when the terminal starts\n- `set`: change to a specific background\n- `enable`: enable a specific background\n- `disable`: disable a specific background\n- `list`: list all backgrounds\n- `add`: add a background to the background folder\n- `delete`: delete a background from the background folder\n\n## Background storage\n\nBackgrounds are stored in `/home/$USER/Pictures/kittyWallpapers/` by defualt\n\nThe current background that is to be displayed is stored in `/home/$USER/Pictures/kittyWallpapers/current/current.png`. You should set the `background_image` property in your `kitty.conf` file to point to this image\n\nAll backgrounds should be in PNG format, as that is only what kitty will accept as a valid image\n- I will eventually add a feature to automatically convert pictures into PNG format once they are added to the background folder\n\nIn the near future, there will be an option to change the location\n',
    'author': 'Brad Culwell',
    'author_email': 'beastwick18@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
