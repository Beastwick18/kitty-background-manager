# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['beastwick18_kitty_background_manager']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=9.1.1,<10.0.0',
 'click[all]>=8.1.3,<9.0.0',
 'pixcat[all]>=0.1.4,<0.2.0',
 'rope>=1.1.1,<2.0.0',
 'typer[all]>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['kittybg = beastwick18_kitty_background_manager.main:app']}

setup_kwargs = {
    'name': 'beastwick18-kitty-background-manager',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Kitty Background Manager\nA cli program for managing your backgrounds for kitty terminal\n\nThis project is WIP for now.\nI plan to add the following features:\n- [X] Config file\n- [X] Option to dim image\n- [ ] Option to scale and crop image\n- [ ] Add `config` command for quickly changing the config file without having to open it\n- [ ] Add playlists... maybe?\n\n## Installation\nThe program requires poetry, python, and pip to install correctly.\n\nTo install Kitty Background Manager, you will have to clone the repository and run the following commands to install the program\n\n```\nchmod +x ./install.sh\n./install.sh\n```\nThe first command you should run after installing is\n```\nkittybg init\n```\nThis command will create the enabled folder and disabled folder as specified in the `config.json` file\n\nThis program uses [typer](https://github.com/tiangolo/typer) for handling the cli portion of the app and [pixcat](https://github.com/mirukana/pixcat) for displaying image previews in the terminal\n\n## Running the program\nOnce the program is installed, you can run it by calling the `kittybg` command from your terminal\n\nThe current arguments the program accepts are:\n- `preview`: Looks for the first occurence of a background in the disabled and enabled folder in that order and shows a preview\n    - Can be run with `--enabled` or `--disabled` to search through just the enabled or disabled folder\n    - Can also be run with `--fill` to make the preview fill the screen or with `--size n` with n being between 0 and 4096 to set the preview images size\n- `add`: Add an image to the background folder\n    - If `preview_on_add` is set to `true` in `config.json`, then everytime an image is added a preview will be shown in the terminal. This is useful for quickly seeing the effects of any edits made by the program\n- `delete`: Looks for the first occurence of a background in the disabled and enabled folder in that order and deletes it.\n    - Can be run with `--enabled` or `--disabled` to search through just the enabled or disabled folder\n- `disable`:Disable a background that is currently enabled\n- `enable`: Enable a background that is currently disabled\n- `init`: Initialize all required directories and create a config.json file if one does not exist\n- `list`: List all enabled and disabled backgrounds, as well as the next background\n- `random`: Set next background to a random one\n    - Can be run with `--silent` to hide the output. Useful for randomizing the background when the terminal starts\n- `set`: Set next background to a specific background (can be an enabled or disabled background)\n\n## Config file\nThe config file for this program is in a json file typically located in `/home/$USER/.config/kittybg/config.json`\n\nThe editable properties stored in this json are the brightness of the image, the contrast of the image, the enabled folder path, and the disabled folder path\n\nAn example config.json looks like this\n```json\n{\n    "options": {\n        "brightness": 0.1,\n        "contrast": 1.15,\n        "enabled_path": "/home/$USER/Pictures/kittyWallpapers/",\n        "disabled_path": "/home/$USER/Pictures/kittyWallpapers/disabled/",\n        "preview_size": 512,\n        "preview_fill": false,\n        "preview_on_add": true\n    }\n}\n```\n\n## Background storage\n\nBackgrounds are stored in `/home/$USER/Pictures/kittyWallpapers/` by defualt\n\nThe current background that is to be displayed is stored in `/home/$USER/Pictures/kittyWallpapers/current/current.png`. You should set the `background_image` property in your `kitty.conf` file to point to this image\n\nAll backgrounds should be in PNG format, as that is only what kitty will accept as a valid image\n- When using the `add` command, the image will automatically be converted into PNG format\n\nIn the near future, there will be an option to change the location\n',
    'author': 'Brad Culwell',
    'author_email': 'beastwick18@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
